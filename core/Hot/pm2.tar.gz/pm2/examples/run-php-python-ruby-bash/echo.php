<?php

while (1) {
    echo 'lol i hate php !';
    sleep(1);
}

 ?>