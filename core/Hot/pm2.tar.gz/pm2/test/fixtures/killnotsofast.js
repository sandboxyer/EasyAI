setInterval(function() {
  console.log('ALIVE');
}, 500);
