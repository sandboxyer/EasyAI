
setInterval(function() {
  console.log('echo.js');
}, 50);

setInterval(function() {
  console.error('echo.js-error');
}, 50);
