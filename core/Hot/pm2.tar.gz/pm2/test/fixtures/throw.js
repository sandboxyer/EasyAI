
throw new Error('Exit error message');
