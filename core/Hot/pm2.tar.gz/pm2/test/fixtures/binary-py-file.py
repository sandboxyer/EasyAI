import time

while True:
    print 'hello'
    time.sleep(1)
