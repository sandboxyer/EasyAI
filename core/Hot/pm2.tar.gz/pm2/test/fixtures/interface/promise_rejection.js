var p = new Promise(function(resolve, reject) {
  //setTimeout(function() {
  //throw new Error('fail')
  abc = asdsad;

    return resolve('ok')
  //}, 200)
})

p.then(function(e) {
})
