
setInterval(function() {
  console.log('OK')
}, 1000)
